export const TEST =
    [
        {
            id: 0,
            question: "test question",
            answers: [
                {
                    id: 1,
                    answer: "test answer",
                    is_correct: true
                }
            ]
        }
    ];